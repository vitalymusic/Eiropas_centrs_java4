function RedText(element){
    document.querySelector(element).style.color="red";
}


export default RedText;
