import redText from './redtext.module';
import Cards from './cards.module';
import $ from 'jquery';
import lc_lightbox from "lightbox-lib";


data = [
    {
        name:"Aboli",
        price:2.36,
        image:"https://www.vangeldernederland.nl/static/uploads/pictures/large/100100-gala-appels.jpg",
        id:1001
    },
    {
        name:"Maize",
        price:1.20,
        image:"https://cdn.barbora.lv/products/8a22acc1-1648-4f19-86be-dfb8c9be7f2f_m.png",
        id:1002
    },
    {
        name:"Doktora desa",
        price:8.20,
        image:"https://rimibaltic-res.cloudinary.com/image/upload/b_white,c_fit,f_auto,h_480,q_auto,w_480/d_ecommerce:backend-fallback.png/MAT_265217_KGM_LV",
        id:1003
    }
]

document.addEventListener("DOMContentLoaded",()=>{
    redText("p");
    redText("h1");
    Cards(data,".products");






});



$(document).ready(()=>{
    $(".card").click(function(){
        $(".card").css("background","");
        console.log($(this));
        $(this).css({
            background:"blue"
        })
    })

})


{/*  */}

    $(document).ready(function() {
        lc_lightbox('#lcl_elems_wrapper a');
        // console.log($obj);
    });