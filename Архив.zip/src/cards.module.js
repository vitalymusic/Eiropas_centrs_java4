export default function Cards(arr,elem){
    arr.forEach(function(item){
        document.querySelector(elem).innerHTML += `
            <div class="card">
                <img src="${item.image}">
                <h3>${item.name}</h3>
                <h5>${(item.price).toFixed(2)}</h5>
                <button data-id="${item.id}">Nopirkt</button>
            </div>
        `;
    })
}